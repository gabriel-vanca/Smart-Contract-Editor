package matchers.component;

public interface Has<T> {
    public boolean matches(T component);
}
