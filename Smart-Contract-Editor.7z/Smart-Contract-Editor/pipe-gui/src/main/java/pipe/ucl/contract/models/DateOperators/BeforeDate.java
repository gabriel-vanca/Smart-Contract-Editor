package pipe.ucl.contract.models.DateOperators;

import pipe.ucl.contract.interfaces.GetCalendar;

import java.util.GregorianCalendar;

public class BeforeDate implements GetCalendar {
    @Override
    public GregorianCalendar GetDiscreteDate() {
        return null;
    }

    //TODO: To be implemented
}
