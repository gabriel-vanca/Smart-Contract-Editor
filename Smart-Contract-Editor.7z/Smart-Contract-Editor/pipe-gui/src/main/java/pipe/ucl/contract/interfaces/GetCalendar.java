package pipe.ucl.contract.interfaces;

import java.util.GregorianCalendar;

public interface GetCalendar {

    public GregorianCalendar GetDiscreteDate();
}
