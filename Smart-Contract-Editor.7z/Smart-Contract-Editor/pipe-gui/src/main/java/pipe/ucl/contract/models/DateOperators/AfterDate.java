package pipe.ucl.contract.models.DateOperators;

import pipe.ucl.contract.interfaces.GetCalendar;

import java.util.GregorianCalendar;

public class AfterDate implements GetCalendar {
    @Override
    public GregorianCalendar GetDiscreteDate() {
        return null;
    }

    //TODO: To be implemented
}
