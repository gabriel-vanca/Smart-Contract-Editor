package pipe.ucl.contract.enums;

public enum StateType {
    START,
    END,
    DEFAULT,
    INTERMEDIARY,
    PAUSE
}
