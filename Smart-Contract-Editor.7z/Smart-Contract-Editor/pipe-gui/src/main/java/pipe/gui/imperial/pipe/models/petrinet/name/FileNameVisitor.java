package pipe.gui.imperial.pipe.models.petrinet.name;

import pipe.gui.imperial.pipe.models.petrinet.name.NameVisitor;

public interface FileNameVisitor extends NameVisitor {
   void visit(PetriNetFileName var1);
}
