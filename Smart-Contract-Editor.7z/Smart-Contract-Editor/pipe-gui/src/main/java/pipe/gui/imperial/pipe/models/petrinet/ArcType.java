package pipe.gui.imperial.pipe.models.petrinet;

public enum ArcType {
   INHIBITOR,
   NORMAL;
}
