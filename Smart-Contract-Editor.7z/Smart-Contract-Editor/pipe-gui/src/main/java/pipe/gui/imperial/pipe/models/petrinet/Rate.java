package pipe.gui.imperial.pipe.models.petrinet;

public interface Rate {
   String getExpression();

   RateType getRateType();
}
