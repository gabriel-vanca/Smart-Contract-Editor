package pipe.gui.imperial.pipe.models.petrinet.name;

public interface NameVisitor {
}
