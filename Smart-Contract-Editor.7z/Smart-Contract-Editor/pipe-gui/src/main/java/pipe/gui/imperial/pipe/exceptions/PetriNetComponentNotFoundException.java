package pipe.gui.imperial.pipe.exceptions;

import pipe.gui.imperial.pipe.exceptions.PetriNetComponentException;

public class PetriNetComponentNotFoundException extends PetriNetComponentException {
   public PetriNetComponentNotFoundException(String message) {
      super(message);
   }
}
