package pipe.gui.imperial.pipe.naming;

public interface MultipleNamer {
   String getPlaceName();

   String getTransitionName();

   String getArcName();
}
