package pipe.gui.imperial.state;

import pipe.gui.imperial.state.State;

public interface ClassifiedState extends State {
   boolean isTangible();
}
