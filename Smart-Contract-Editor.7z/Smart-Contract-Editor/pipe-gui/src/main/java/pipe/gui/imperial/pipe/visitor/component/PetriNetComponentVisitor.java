package pipe.gui.imperial.pipe.visitor.component;

public interface PetriNetComponentVisitor {
}
