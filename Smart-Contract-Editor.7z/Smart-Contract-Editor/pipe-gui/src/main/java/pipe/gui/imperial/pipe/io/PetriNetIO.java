package pipe.gui.imperial.pipe.io;

public interface PetriNetIO extends PetriNetReader, PetriNetWriter {
}
