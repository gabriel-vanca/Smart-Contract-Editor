package pipe.gui.imperial.pipe.exceptions;

public class PetriNetComponentException extends Exception {
   public PetriNetComponentException(String message) {
      super(message);
   }

   public PetriNetComponentException(Throwable throwable) {
      super(throwable);
   }
}
