package pipe.gui.imperial.pipe.parsers;

import pipe.gui.imperial.pipe.parsers.FunctionalResults;

public interface FunctionalWeightParser {
   FunctionalResults evaluateExpression(String var1);
}
