package pipe.gui.imperial.pipe.models.petrinet;

public enum RateType {
   NORMAL_RATE,
   RATE_PARAMETER;
}
