package pipe.gui.imperial.pipe.naming;

public interface UniqueNamer {
   String getName();

   boolean isUniqueName(String var1);
}
